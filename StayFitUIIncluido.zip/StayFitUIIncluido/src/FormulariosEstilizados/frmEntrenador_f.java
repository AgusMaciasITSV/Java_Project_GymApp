package FormulariosEstilizados;


import BaseDatos.BaseDatos;
import Clases.Cliente;
import Clases.Dia;
import Clases.Ejercicio;
import Clases.Plan;

import java.awt.Color;

import java.util.ArrayList;
import javax.swing.DefaultListModel;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class frmEntrenador_f extends javax.swing.JFrame {
    private int xMouse,yMouse;
    Color lOrange = new Color(255,192,98);
    Color orange = new Color(255,153,0);
    Color dOrange = new Color(255,120 ,0);
    Color white = new Color(255,255,255);
    Color grey = new Color(153,153,153);
    Color red = new Color(255,0,0);
    Color dRed = new Color(145,0 ,0);
    
    private DefaultTableModel dtm = new DefaultTableModel();
    private DefaultListModel dmList = new DefaultListModel();
    
    private ArrayList<Cliente> listaClientes;
    
    public frmEntrenador_f(ArrayList<Cliente> listaClientes) {
        initComponents();
        ltEjer.setModel(dmList);
        this.listaClientes = listaClientes;
        
        completarTabla();
        actualizarCbPlanes();
        actualizarCbDias();
        actualizarListaEjercicios();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        pnlHeading = new javax.swing.JPanel();
        pnlExitBtn = new javax.swing.JPanel();
        lblExitBtn = new javax.swing.JLabel();
        cbPlan = new javax.swing.JComboBox<>();
        cbDias = new javax.swing.JComboBox<>();
        lblDia = new javax.swing.JLabel();
        lblPlan = new javax.swing.JLabel();
        lblEjercicios = new javax.swing.JLabel();
        lblClientes = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblDeClientes = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        ltEjer = new javax.swing.JList<>();
        pnlAñadirPlan = new javax.swing.JPanel();
        lblAñadirPlan = new javax.swing.JLabel();
        pnlBorrarPlan = new javax.swing.JPanel();
        lblBorrarPlan = new javax.swing.JLabel();
        pnlVerCliente = new javax.swing.JPanel();
        lblVerCliente = new javax.swing.JLabel();
        pnlAñadirDia = new javax.swing.JPanel();
        lblAñadirDia = new javax.swing.JLabel();
        pnlEliminarDia = new javax.swing.JPanel();
        lblEliminarDia = new javax.swing.JLabel();
        pnlAñadirEjercicio = new javax.swing.JPanel();
        lblAñadirEjercicio = new javax.swing.JLabel();
        pnlEditarEjercicio = new javax.swing.JPanel();
        lblEditarEjercicio = new javax.swing.JLabel();
        pnlEliminarEjercicio = new javax.swing.JPanel();
        lblEliminarEjercicio = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnlHeading.setBackground(new java.awt.Color(255, 153, 0));
        pnlHeading.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                pnlHeadingMouseDragged(evt);
            }
        });
        pnlHeading.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pnlHeadingMousePressed(evt);
            }
        });

        pnlExitBtn.setBackground(new java.awt.Color(255, 153, 0));

        lblExitBtn.setFont(new java.awt.Font("Open Sans", 1, 24)); // NOI18N
        lblExitBtn.setForeground(new java.awt.Color(255, 255, 255));
        lblExitBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblExitBtn.setText("X");
        lblExitBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblExitBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblExitBtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblExitBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblExitBtnMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblExitBtnMousePressed(evt);
            }
        });

        javax.swing.GroupLayout pnlExitBtnLayout = new javax.swing.GroupLayout(pnlExitBtn);
        pnlExitBtn.setLayout(pnlExitBtnLayout);
        pnlExitBtnLayout.setHorizontalGroup(
            pnlExitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblExitBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );
        pnlExitBtnLayout.setVerticalGroup(
            pnlExitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlExitBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout pnlHeadingLayout = new javax.swing.GroupLayout(pnlHeading);
        pnlHeading.setLayout(pnlHeadingLayout);
        pnlHeadingLayout.setHorizontalGroup(
            pnlHeadingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeadingLayout.createSequentialGroup()
                .addComponent(pnlExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 750, Short.MAX_VALUE))
        );
        pnlHeadingLayout.setVerticalGroup(
            pnlHeadingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHeadingLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(pnlExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, -1));

        cbPlan.setBackground(new java.awt.Color(0, 0, 0));
        cbPlan.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        cbPlan.setForeground(new java.awt.Color(255, 255, 255));
        cbPlan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPlanActionPerformed(evt);
            }
        });
        jPanel1.add(cbPlan, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 70, 90, -1));

        cbDias.setBackground(new java.awt.Color(0, 0, 0));
        cbDias.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        cbDias.setForeground(new java.awt.Color(255, 255, 255));
        cbDias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbDiasActionPerformed(evt);
            }
        });
        jPanel1.add(cbDias, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 170, 90, -1));

        lblDia.setBackground(new java.awt.Color(0, 0, 0));
        lblDia.setFont(new java.awt.Font("Open Sans", 1, 18)); // NOI18N
        lblDia.setForeground(new java.awt.Color(255, 255, 255));
        lblDia.setText("Días");
        jPanel1.add(lblDia, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 170, 65, 30));

        lblPlan.setBackground(new java.awt.Color(0, 0, 0));
        lblPlan.setFont(new java.awt.Font("Open Sans", 1, 18)); // NOI18N
        lblPlan.setForeground(new java.awt.Color(255, 255, 255));
        lblPlan.setText("Planes");
        jPanel1.add(lblPlan, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 70, 65, 30));

        lblEjercicios.setBackground(new java.awt.Color(0, 0, 0));
        lblEjercicios.setFont(new java.awt.Font("Open Sans", 1, 18)); // NOI18N
        lblEjercicios.setForeground(new java.awt.Color(255, 255, 255));
        lblEjercicios.setText("Ejercicios");
        jPanel1.add(lblEjercicios, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 330, 120, -1));

        lblClientes.setBackground(new java.awt.Color(0, 0, 0));
        lblClientes.setFont(new java.awt.Font("Open Sans", 1, 18)); // NOI18N
        lblClientes.setForeground(new java.awt.Color(255, 255, 255));
        lblClientes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblClientes.setText("Clientes");
        jPanel1.add(lblClientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 65, 310, 30));

        jScrollPane1.setBackground(new java.awt.Color(0, 0, 0));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));

        tblDeClientes.setBackground(new java.awt.Color(0, 0, 0));
        tblDeClientes.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        tblDeClientes.setForeground(new java.awt.Color(255, 255, 255));
        tblDeClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Apellido", "Edad"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblDeClientes);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 310, 400));

        ltEjer.setBackground(new java.awt.Color(0, 0, 0));
        ltEjer.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        ltEjer.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane2.setViewportView(ltEjer);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 330, 230, 181));

        pnlAñadirPlan.setBackground(new java.awt.Color(255, 153, 0));

        lblAñadirPlan.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblAñadirPlan.setForeground(new java.awt.Color(255, 255, 255));
        lblAñadirPlan.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAñadirPlan.setText("Añadir Plan");
        lblAñadirPlan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblAñadirPlan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAñadirPlanMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAñadirPlanMouseEntered(evt);
            }
        });

        javax.swing.GroupLayout pnlAñadirPlanLayout = new javax.swing.GroupLayout(pnlAñadirPlan);
        pnlAñadirPlan.setLayout(pnlAñadirPlanLayout);
        pnlAñadirPlanLayout.setHorizontalGroup(
            pnlAñadirPlanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblAñadirPlan, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        pnlAñadirPlanLayout.setVerticalGroup(
            pnlAñadirPlanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAñadirPlanLayout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addComponent(lblAñadirPlan, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlAñadirPlan, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 70, 140, 30));

        pnlBorrarPlan.setBackground(new java.awt.Color(255, 153, 0));

        lblBorrarPlan.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblBorrarPlan.setForeground(new java.awt.Color(255, 255, 255));
        lblBorrarPlan.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBorrarPlan.setText("Borrar Plan");
        lblBorrarPlan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblBorrarPlan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblBorrarPlanMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlBorrarPlanLayout = new javax.swing.GroupLayout(pnlBorrarPlan);
        pnlBorrarPlan.setLayout(pnlBorrarPlanLayout);
        pnlBorrarPlanLayout.setHorizontalGroup(
            pnlBorrarPlanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblBorrarPlan, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        pnlBorrarPlanLayout.setVerticalGroup(
            pnlBorrarPlanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlBorrarPlanLayout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addComponent(lblBorrarPlan, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlBorrarPlan, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 110, 140, 30));

        pnlVerCliente.setBackground(new java.awt.Color(255, 153, 0));

        lblVerCliente.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblVerCliente.setForeground(new java.awt.Color(255, 255, 255));
        lblVerCliente.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblVerCliente.setText("Ver cliente");
        lblVerCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblVerCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblVerClienteMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlVerClienteLayout = new javax.swing.GroupLayout(pnlVerCliente);
        pnlVerCliente.setLayout(pnlVerClienteLayout);
        pnlVerClienteLayout.setHorizontalGroup(
            pnlVerClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblVerCliente, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        pnlVerClienteLayout.setVerticalGroup(
            pnlVerClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlVerClienteLayout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addComponent(lblVerCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlVerCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 520, 140, 30));

        pnlAñadirDia.setBackground(new java.awt.Color(255, 153, 0));

        lblAñadirDia.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblAñadirDia.setForeground(new java.awt.Color(255, 255, 255));
        lblAñadirDia.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAñadirDia.setText("Añadir Dia");
        lblAñadirDia.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblAñadirDia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAñadirDiaMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlAñadirDiaLayout = new javax.swing.GroupLayout(pnlAñadirDia);
        pnlAñadirDia.setLayout(pnlAñadirDiaLayout);
        pnlAñadirDiaLayout.setHorizontalGroup(
            pnlAñadirDiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblAñadirDia, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        pnlAñadirDiaLayout.setVerticalGroup(
            pnlAñadirDiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAñadirDiaLayout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addComponent(lblAñadirDia, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlAñadirDia, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 170, 140, 30));

        pnlEliminarDia.setBackground(new java.awt.Color(255, 153, 0));

        lblEliminarDia.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblEliminarDia.setForeground(new java.awt.Color(255, 255, 255));
        lblEliminarDia.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEliminarDia.setText("Eliminar Dia");
        lblEliminarDia.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblEliminarDia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblEliminarDiaMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlEliminarDiaLayout = new javax.swing.GroupLayout(pnlEliminarDia);
        pnlEliminarDia.setLayout(pnlEliminarDiaLayout);
        pnlEliminarDiaLayout.setHorizontalGroup(
            pnlEliminarDiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblEliminarDia, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        pnlEliminarDiaLayout.setVerticalGroup(
            pnlEliminarDiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlEliminarDiaLayout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addComponent(lblEliminarDia, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlEliminarDia, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 210, 140, 30));

        pnlAñadirEjercicio.setBackground(new java.awt.Color(255, 153, 0));

        lblAñadirEjercicio.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblAñadirEjercicio.setForeground(new java.awt.Color(255, 255, 255));
        lblAñadirEjercicio.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAñadirEjercicio.setText("Añadir Ejercicio");
        lblAñadirEjercicio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblAñadirEjercicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAñadirEjercicioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAñadirEjercicioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblAñadirEjercicioMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblAñadirEjercicioMousePressed(evt);
            }
        });

        javax.swing.GroupLayout pnlAñadirEjercicioLayout = new javax.swing.GroupLayout(pnlAñadirEjercicio);
        pnlAñadirEjercicio.setLayout(pnlAñadirEjercicioLayout);
        pnlAñadirEjercicioLayout.setHorizontalGroup(
            pnlAñadirEjercicioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblAñadirEjercicio, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        pnlAñadirEjercicioLayout.setVerticalGroup(
            pnlAñadirEjercicioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAñadirEjercicioLayout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addComponent(lblAñadirEjercicio, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlAñadirEjercicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 380, 140, 30));

        pnlEditarEjercicio.setBackground(new java.awt.Color(255, 153, 0));

        lblEditarEjercicio.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblEditarEjercicio.setForeground(new java.awt.Color(255, 255, 255));
        lblEditarEjercicio.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEditarEjercicio.setText("Editar Ejercicio");
        lblEditarEjercicio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblEditarEjercicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblEditarEjercicioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblEditarEjercicioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblEditarEjercicioMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblEditarEjercicioMousePressed(evt);
            }
        });

        javax.swing.GroupLayout pnlEditarEjercicioLayout = new javax.swing.GroupLayout(pnlEditarEjercicio);
        pnlEditarEjercicio.setLayout(pnlEditarEjercicioLayout);
        pnlEditarEjercicioLayout.setHorizontalGroup(
            pnlEditarEjercicioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblEditarEjercicio, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        pnlEditarEjercicioLayout.setVerticalGroup(
            pnlEditarEjercicioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlEditarEjercicioLayout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addComponent(lblEditarEjercicio, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlEditarEjercicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 420, 140, 30));

        pnlEliminarEjercicio.setBackground(new java.awt.Color(255, 153, 0));

        lblEliminarEjercicio.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblEliminarEjercicio.setForeground(new java.awt.Color(255, 255, 255));
        lblEliminarEjercicio.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEliminarEjercicio.setText("Eliminar Ejercicio");
        lblEliminarEjercicio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblEliminarEjercicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblEliminarEjercicioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblEliminarEjercicioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblEliminarEjercicioMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblEliminarEjercicioMousePressed(evt);
            }
        });

        javax.swing.GroupLayout pnlEliminarEjercicioLayout = new javax.swing.GroupLayout(pnlEliminarEjercicio);
        pnlEliminarEjercicio.setLayout(pnlEliminarEjercicioLayout);
        pnlEliminarEjercicioLayout.setHorizontalGroup(
            pnlEliminarEjercicioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblEliminarEjercicio, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        pnlEliminarEjercicioLayout.setVerticalGroup(
            pnlEliminarEjercicioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlEliminarEjercicioLayout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addComponent(lblEliminarEjercicio, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlEliminarEjercicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 460, 140, 30));

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 270, 430, 20));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // EVENTOS 
    private void lblExitBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMouseClicked
        BaseDatos.escribirClientes(listaClientes);
        System.exit(0);
    }//GEN-LAST:event_lblExitBtnMouseClicked

    private void lblExitBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMouseEntered
        pnlExitBtn.setBackground(red);
    }//GEN-LAST:event_lblExitBtnMouseEntered

    private void lblExitBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMouseExited
        pnlExitBtn.setBackground(orange);
    }//GEN-LAST:event_lblExitBtnMouseExited

    private void lblExitBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMousePressed
        pnlExitBtn.setBackground(dRed);
    }//GEN-LAST:event_lblExitBtnMousePressed

    private void pnlHeadingMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlHeadingMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_pnlHeadingMouseDragged

    private void pnlHeadingMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlHeadingMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_pnlHeadingMousePressed

    private void cbPlanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPlanActionPerformed
        actualizarCbDias();
    }//GEN-LAST:event_cbPlanActionPerformed

    private void cbDiasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbDiasActionPerformed
        actualizarListaEjercicios();
    }//GEN-LAST:event_cbDiasActionPerformed

    private void lblAñadirPlanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirPlanMouseClicked
        if(tblDeClientes.getSelectedRow() == -1) {
            String mensaje = "No ha seleccionado o no existe ningun cliente";
            int tipoJOption = JOptionPane.INFORMATION_MESSAGE;
            JOptionPane.showMessageDialog(null, mensaje, "ERROR", tipoJOption);
            return;
        }
        this.setVisible(false);
        frmCrearPlan_f frmCrearPlan = new frmCrearPlan_f(this);
        frmCrearPlan.setVisible(true);
    }//GEN-LAST:event_lblAñadirPlanMouseClicked

    private void lblBorrarPlanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBorrarPlanMouseClicked
        if (listaClientes.isEmpty()) {
            return;
        }
        if (tblDeClientes.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione un cliente para acceder a sus planes");
            return;
        }
        if(cbPlan.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(null, "No tienen ningun dia para borrar");
            return;
        }
        int opcion = JOptionPane.showConfirmDialog(this, "¿Estas seguro que quiere eliminar el plan?", "Confirmar eliminar plan", 0, 1);
        if(opcion == 0) {
            listaClientes.get(tblDeClientes.getSelectedRow()).getListaPlanes().remove(cbPlan.getSelectedIndex());
            actualizarCbPlanes();
            actualizarCbDias();
            actualizarListaEjercicios();
        }
    }//GEN-LAST:event_lblBorrarPlanMouseClicked

    private void lblAñadirDiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirDiaMouseClicked
        this.setVisible(false);
        frmCrearDia_f frmCrearDia = new frmCrearDia_f(this);
        frmCrearDia.setVisible(true);
    }//GEN-LAST:event_lblAñadirDiaMouseClicked

    private void lblEliminarDiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEliminarDiaMouseClicked
        if (listaClientes.isEmpty()) {
            return;
        }
        if (tblDeClientes.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione un cliente para acceder a sus planes");
            return;
        }
        if(cbPlan.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(null, "No tienen ningun plan para borrar");
            return;
        }
        if(cbDias.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(null, "No tienen ningun dia para borrar");
            return;
        }
        
        int opcion = JOptionPane.showConfirmDialog(this, "¿Estas seguro que quiere eliminar el dia?", "Confirmar eliminar plan", 0, 1);
        
        if(opcion == 0) {
            listaClientes.get(tblDeClientes.getSelectedRow()).getListaPlanes().get(cbPlan.getSelectedIndex()).getListaDias().remove(cbDias.getSelectedIndex());
            actualizarCbPlanes();
            actualizarCbDias();
            actualizarListaEjercicios();
        }
    }//GEN-LAST:event_lblEliminarDiaMouseClicked

    private void lblAñadirEjercicioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirEjercicioMouseClicked
        this.setVisible(false);
        frmEjercicio_f frmCrearEjercicio = new frmEjercicio_f(this);
        frmCrearEjercicio.setVisible(true);
    }//GEN-LAST:event_lblAñadirEjercicioMouseClicked

    private void lblAñadirEjercicioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirEjercicioMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_lblAñadirEjercicioMouseEntered

    private void lblAñadirEjercicioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirEjercicioMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_lblAñadirEjercicioMouseExited

    private void lblAñadirEjercicioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirEjercicioMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_lblAñadirEjercicioMousePressed

    private void lblEditarEjercicioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEditarEjercicioMouseClicked
        if(ltEjer.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(null, "No ha seleccionado o no existe ningun ejercicio");
            return;
        }
        
        Cliente client = listaClientes.get(tblDeClientes.getSelectedRow());
        Plan plan = client.getListaPlanes().get(cbPlan.getSelectedIndex());
        Dia dia = plan.getListaDias().get(cbDias.getSelectedIndex());
        
        
        
        Ejercicio ejer = dia.getListaEjercicios().get(ltEjer.getSelectedIndex());
        int indice = ltEjer.getSelectedIndex();
                
        this.setVisible(false);
        frmEjercicio_f frmCrearEjercicio = new frmEjercicio_f(this, ejer, indice);
        frmCrearEjercicio.setVisible(true);
    }//GEN-LAST:event_lblEditarEjercicioMouseClicked

    private void lblEditarEjercicioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEditarEjercicioMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_lblEditarEjercicioMouseEntered

    private void lblEditarEjercicioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEditarEjercicioMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_lblEditarEjercicioMouseExited

    private void lblEditarEjercicioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEditarEjercicioMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_lblEditarEjercicioMousePressed

    private void lblEliminarEjercicioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEliminarEjercicioMouseClicked
        if (listaClientes.isEmpty()) {
            return;
        }
        if (tblDeClientes.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione un cliente para acceder a sus planes");
            return;
        }
        if(cbPlan.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(null, "No tienen ningun plan para borrar.");
            return;
        }
        if(cbDias.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(null, "No tienen ningun dia para borrar.");
            return;
        }
        if(ltEjer.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione algun ejercicio o cree uno.");
            return;
        }
        if(dtm.getRowCount() == 1) {
            JOptionPane.showMessageDialog(null, "No puede eliminar el ultimo ejercicio del dia.");
            return;
        }
        System.out.println(dtm.getRowCount());
        listaClientes.get(tblDeClientes.getSelectedRow()).
                getListaPlanes().get(cbPlan.getSelectedIndex()).
                getListaDias().get(cbDias.getSelectedIndex()).
                getListaEjercicios().remove(ltEjer.getSelectedIndex() -1);
        actualizarListaEjercicios();
    }//GEN-LAST:event_lblEliminarEjercicioMouseClicked

    private void lblEliminarEjercicioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEliminarEjercicioMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_lblEliminarEjercicioMouseEntered

    private void lblEliminarEjercicioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEliminarEjercicioMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_lblEliminarEjercicioMouseExited

    private void lblEliminarEjercicioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEliminarEjercicioMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_lblEliminarEjercicioMousePressed

    private void lblAñadirPlanMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirPlanMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_lblAñadirPlanMouseEntered

    private void lblVerClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblVerClienteMouseClicked
        actualizarCbPlanes();
        actualizarCbDias();
    }//GEN-LAST:event_lblVerClienteMouseClicked

    
    // FUNCIONES
    
    private void completarTabla() {
        String[] columnas = {"Nombre", "Apellido", "Edad"};
        dtm.setColumnIdentifiers(columnas);
        
        if(listaClientes.isEmpty()) {
            String mensaje = "No existe ningun cliente";
            int tipoJOption = JOptionPane.INFORMATION_MESSAGE;
            JOptionPane.showMessageDialog(null, mensaje, "Clientes", tipoJOption);
            return;
        }
        for (Cliente client : listaClientes) {
            String nombre = client.getInformacion().getNombre();
            String apellido = client.getInformacion().getApellido();
            String edad = String.valueOf(client.getInformacion().getEdad());
            
            String[] fila = {nombre, apellido, edad};
            
            dtm.addRow(fila);
        }
        tblDeClientes.setModel(dtm);
    }
    
    private void actualizarCbPlanes() {
        cbPlan.removeAllItems();
        
        if(tblDeClientes.getSelectedRow() == -1) {
            return;
        }
        
        Cliente client = listaClientes.get(tblDeClientes.getSelectedRow());
        for (int i = 0; i < client.getListaPlanes().size(); i++) {
            cbPlan.addItem("Plan N°" + (i+1));
        }
        
    }
    
    private void actualizarCbDias() {
        cbDias.removeAllItems();
        if(cbPlan.getSelectedIndex() == -1) {
            return;
        }
        Cliente cleint = listaClientes.get(tblDeClientes.getSelectedRow());
        Plan plan = cleint.getListaPlanes().get(cbPlan.getSelectedIndex());
        for (int i = 0; i < plan.getListaDias().size(); i++) {
            cbDias.addItem("Dia N°" + (1+i));
        }
    }
    
    private void actualizarListaEjercicios() {
        dmList.clear();
        if(cbDias.getSelectedIndex() == -1) {
            return;
        }
        Cliente cleint = listaClientes.get(tblDeClientes.getSelectedRow());
        Plan plan = cleint.getListaPlanes().get(cbPlan.getSelectedIndex());
        Dia dia = plan.getListaDias().get(cbDias.getSelectedIndex());
        
        for (int i = 0; i < dia.getListaEjercicios().size(); i++) {
            String nombre = dia.getListaEjercicios().get(i).getNombreEjercicio();
            int series = dia.getListaEjercicios().get(i).getSeries();
            int reps = dia.getListaEjercicios().get(i).getRepeticiones();
            
            if(reps != 0) { // si rep es igual a cero significa que es al fallo
                dmList.addElement(nombre + ": " + series + " x " + reps);
            } else {
                dmList.addElement(nombre + ": " + series + " x  al fallo");
            }
        }
    }
    
    public void añadirPlan(Plan plan) {
        listaClientes.get(tblDeClientes.getSelectedRow()).getListaPlanes().add(plan);

        actualizarCbPlanes();
        actualizarCbDias();
        actualizarListaEjercicios();
    }
    
    public void añadirDia(Dia dia) {
        listaClientes.get(tblDeClientes.getSelectedRow()).getListaPlanes().get(cbPlan.getSelectedIndex()).getListaDias().add(dia);
        
        actualizarCbDias();
        actualizarListaEjercicios();
    }
    public void añadirEjercicio(Ejercicio ejer) {
        listaClientes.get(tblDeClientes.getSelectedRow()).getListaPlanes().get(cbPlan.getSelectedIndex()).getListaDias().get(cbDias.getSelectedIndex()).getListaEjercicios().add(ejer);
        actualizarListaEjercicios();
    }
    public void remplazarEjercicio(Ejercicio ejer, int indice) {
        listaClientes.get(tblDeClientes.getSelectedRow()).getListaPlanes().get(cbPlan.getSelectedIndex()).getListaDias().get(cbDias.getSelectedIndex()).getListaEjercicios().set(indice, ejer);
        actualizarListaEjercicios();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbDias;
    private javax.swing.JComboBox<String> cbPlan;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblAñadirDia;
    private javax.swing.JLabel lblAñadirEjercicio;
    private javax.swing.JLabel lblAñadirPlan;
    private javax.swing.JLabel lblBorrarPlan;
    private javax.swing.JLabel lblClientes;
    private javax.swing.JLabel lblDia;
    private javax.swing.JLabel lblEditarEjercicio;
    private javax.swing.JLabel lblEjercicios;
    private javax.swing.JLabel lblEliminarDia;
    private javax.swing.JLabel lblEliminarEjercicio;
    private javax.swing.JLabel lblExitBtn;
    private javax.swing.JLabel lblPlan;
    private javax.swing.JLabel lblVerCliente;
    private javax.swing.JList<String> ltEjer;
    private javax.swing.JPanel pnlAñadirDia;
    private javax.swing.JPanel pnlAñadirEjercicio;
    private javax.swing.JPanel pnlAñadirPlan;
    private javax.swing.JPanel pnlBorrarPlan;
    private javax.swing.JPanel pnlEditarEjercicio;
    private javax.swing.JPanel pnlEliminarDia;
    private javax.swing.JPanel pnlEliminarEjercicio;
    private javax.swing.JPanel pnlExitBtn;
    private javax.swing.JPanel pnlHeading;
    private javax.swing.JPanel pnlVerCliente;
    private javax.swing.JTable tblDeClientes;
    // End of variables declaration//GEN-END:variables
}
