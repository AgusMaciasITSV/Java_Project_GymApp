/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package FormulariosEstilizados;

import BaseDatos.BaseDatos;
import Clases.Dia;
import Clases.Plan;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */
public class frmCrearPlan_f extends javax.swing.JFrame {
    int xMouse,yMouse;
    Color lOrange = new Color(255,192,98);
    Color orange = new Color(255,153,0);
    Color dOrange = new Color(255,120 ,0);
    Color white = new Color(255,255,255);
    Color grey = new Color(153,153,153);
    Color red = new Color(255,0,0);
    Color dRed = new Color(145,0 ,0);
    
    private frmEntrenador_f parent;
    private ArrayList<Dia> listaDias = new ArrayList();
    private DefaultListModel DmList = new DefaultListModel();
    
  
    
    public frmCrearPlan_f(frmEntrenador_f frmEntre) {
        initComponents();
        this.setLocationRelativeTo(null);
        
        parent = frmEntre;
        ltDias.setModel(DmList);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ltDias = new javax.swing.JList<>();
        pnlAñadirDia = new javax.swing.JPanel();
        lblAñadirDia = new javax.swing.JLabel();
        lblFormularioPlan = new javax.swing.JLabel();
        pnlCrearPlan = new javax.swing.JPanel();
        lblCrearPlan = new javax.swing.JLabel();
        pnlCancelar = new javax.swing.JPanel();
        lblCancelar = new javax.swing.JLabel();
        pnlHeading = new javax.swing.JPanel();
        pnlExitBtn = new javax.swing.JPanel();
        lblExitBtn = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));

        ltDias.setBackground(new java.awt.Color(0, 0, 0));
        ltDias.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        ltDias.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(ltDias);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 120, 170, 190));

        pnlAñadirDia.setBackground(new java.awt.Color(255, 153, 0));

        lblAñadirDia.setFont(new java.awt.Font("Open Sans", 1, 18)); // NOI18N
        lblAñadirDia.setForeground(new java.awt.Color(255, 255, 255));
        lblAñadirDia.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAñadirDia.setText("Añadir Dia");
        lblAñadirDia.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblAñadirDia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAñadirDiaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAñadirDiaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblAñadirDiaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblAñadirDiaMousePressed(evt);
            }
        });

        javax.swing.GroupLayout pnlAñadirDiaLayout = new javax.swing.GroupLayout(pnlAñadirDia);
        pnlAñadirDia.setLayout(pnlAñadirDiaLayout);
        pnlAñadirDiaLayout.setHorizontalGroup(
            pnlAñadirDiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAñadirDiaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblAñadirDia, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        pnlAñadirDiaLayout.setVerticalGroup(
            pnlAñadirDiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAñadirDiaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblAñadirDia, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlAñadirDia, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 170, 40));

        lblFormularioPlan.setFont(new java.awt.Font("Open Sans", 1, 24)); // NOI18N
        lblFormularioPlan.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFormularioPlan.setText("Formulario Plan");
        jPanel1.add(lblFormularioPlan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 400, -1));

        pnlCrearPlan.setBackground(new java.awt.Color(255, 153, 0));

        lblCrearPlan.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblCrearPlan.setForeground(new java.awt.Color(255, 255, 255));
        lblCrearPlan.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCrearPlan.setText("Crear Plan");
        lblCrearPlan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblCrearPlan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCrearPlanMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblCrearPlanMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblCrearPlanMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblCrearPlanMousePressed(evt);
            }
        });

        javax.swing.GroupLayout pnlCrearPlanLayout = new javax.swing.GroupLayout(pnlCrearPlan);
        pnlCrearPlan.setLayout(pnlCrearPlanLayout);
        pnlCrearPlanLayout.setHorizontalGroup(
            pnlCrearPlanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCrearPlan, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
        );
        pnlCrearPlanLayout.setVerticalGroup(
            pnlCrearPlanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCrearPlan, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        jPanel1.add(pnlCrearPlan, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 350, 150, 40));

        pnlCancelar.setBackground(new java.awt.Color(255, 153, 0));

        lblCancelar.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblCancelar.setForeground(new java.awt.Color(255, 255, 255));
        lblCancelar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCancelar.setText("Cancelar");
        lblCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblCancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCancelarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblCancelarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblCancelarMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblCancelarMousePressed(evt);
            }
        });

        javax.swing.GroupLayout pnlCancelarLayout = new javax.swing.GroupLayout(pnlCancelar);
        pnlCancelar.setLayout(pnlCancelarLayout);
        pnlCancelarLayout.setHorizontalGroup(
            pnlCancelarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
        );
        pnlCancelarLayout.setVerticalGroup(
            pnlCancelarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        jPanel1.add(pnlCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 350, 150, 40));

        pnlHeading.setBackground(new java.awt.Color(255, 153, 0));
        pnlHeading.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                pnlHeadingMouseDragged(evt);
            }
        });
        pnlHeading.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pnlHeadingMousePressed(evt);
            }
        });

        pnlExitBtn.setBackground(new java.awt.Color(255, 153, 0));

        lblExitBtn.setFont(new java.awt.Font("Open Sans", 1, 24)); // NOI18N
        lblExitBtn.setForeground(new java.awt.Color(255, 255, 255));
        lblExitBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblExitBtn.setText("X");
        lblExitBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblExitBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblExitBtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblExitBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblExitBtnMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblExitBtnMousePressed(evt);
            }
        });

        javax.swing.GroupLayout pnlExitBtnLayout = new javax.swing.GroupLayout(pnlExitBtn);
        pnlExitBtn.setLayout(pnlExitBtnLayout);
        pnlExitBtnLayout.setHorizontalGroup(
            pnlExitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlExitBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        pnlExitBtnLayout.setVerticalGroup(
            pnlExitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlExitBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout pnlHeadingLayout = new javax.swing.GroupLayout(pnlHeading);
        pnlHeading.setLayout(pnlHeadingLayout);
        pnlHeadingLayout.setHorizontalGroup(
            pnlHeadingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeadingLayout.createSequentialGroup()
                .addComponent(pnlExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlHeadingLayout.setVerticalGroup(
            pnlHeadingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHeadingLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(pnlExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblCrearPlanMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCrearPlanMouseEntered
        pnlCrearPlan.setBackground(lOrange);
    }//GEN-LAST:event_lblCrearPlanMouseEntered

    private void lblCancelarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCancelarMouseEntered
        pnlCancelar.setBackground(lOrange);
    }//GEN-LAST:event_lblCancelarMouseEntered

    private void lblAñadirDiaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirDiaMouseEntered
        pnlAñadirDia.setBackground(lOrange);
    }//GEN-LAST:event_lblAñadirDiaMouseEntered

    private void lblCrearPlanMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCrearPlanMousePressed
        pnlCrearPlan.setBackground(dOrange);
    }//GEN-LAST:event_lblCrearPlanMousePressed

    private void lblAñadirDiaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirDiaMousePressed
        pnlAñadirDia.setBackground(dOrange);
    }//GEN-LAST:event_lblAñadirDiaMousePressed

    private void lblCancelarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCancelarMousePressed
        pnlCancelar.setBackground(dOrange);
    }//GEN-LAST:event_lblCancelarMousePressed

    private void lblCancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCancelarMouseClicked
        parent.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_lblCancelarMouseClicked

    private void lblCrearPlanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCrearPlanMouseClicked
         if(listaDias.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Para crear un plan tiene que añadir dias");
            return;
        }
        
        parent.añadirPlan(new Plan(listaDias));
        JOptionPane.showMessageDialog(null, "Se añadio el plan exitosamente");
        
        parent.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_lblCrearPlanMouseClicked

    private void lblAñadirDiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirDiaMouseClicked
        this.setVisible(false);
        frmCrearDia_f frmDia = new frmCrearDia_f(this);
        frmDia.setVisible(true);
    }//GEN-LAST:event_lblAñadirDiaMouseClicked

    private void lblExitBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMouseClicked
        parent.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_lblExitBtnMouseClicked

    private void lblExitBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMouseEntered
        pnlExitBtn.setBackground(Color.red);
    }//GEN-LAST:event_lblExitBtnMouseEntered

    private void lblExitBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMouseExited
        pnlExitBtn.setBackground(new Color(255,153,0));
    }//GEN-LAST:event_lblExitBtnMouseExited

    private void lblExitBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMousePressed
        pnlExitBtn.setBackground(new Color(145, 0 , 0));
    }//GEN-LAST:event_lblExitBtnMousePressed

    private void pnlHeadingMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlHeadingMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_pnlHeadingMouseDragged

    private void pnlHeadingMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlHeadingMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_pnlHeadingMousePressed

    private void lblAñadirDiaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirDiaMouseExited
        pnlAñadirDia.setBackground(new Color(255,153,0));
    }//GEN-LAST:event_lblAñadirDiaMouseExited

    private void lblCrearPlanMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCrearPlanMouseExited
        pnlCrearPlan.setBackground(new Color(255,153,0));
    }//GEN-LAST:event_lblCrearPlanMouseExited

    private void lblCancelarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCancelarMouseExited
        pnlCancelar.setBackground(new Color(255,153,0));
    }//GEN-LAST:event_lblCancelarMouseExited

    public void añadirDia(Dia dia) {
        listaDias.add(dia);
        DmList.addElement("dia " + listaDias.size());
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblAñadirDia;
    private javax.swing.JLabel lblCancelar;
    private javax.swing.JLabel lblCrearPlan;
    private javax.swing.JLabel lblExitBtn;
    private javax.swing.JLabel lblFormularioPlan;
    private javax.swing.JList<String> ltDias;
    private javax.swing.JPanel pnlAñadirDia;
    private javax.swing.JPanel pnlCancelar;
    private javax.swing.JPanel pnlCrearPlan;
    private javax.swing.JPanel pnlExitBtn;
    private javax.swing.JPanel pnlHeading;
    // End of variables declaration//GEN-END:variables
}
