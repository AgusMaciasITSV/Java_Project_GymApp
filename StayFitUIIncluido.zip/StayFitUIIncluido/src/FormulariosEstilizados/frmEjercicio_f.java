
package FormulariosEstilizados;

import Clases.Ejercicio;
import java.awt.Color;
import javax.swing.JOptionPane;


public class frmEjercicio_f extends javax.swing.JFrame {
    private boolean esParaRemplazar = false;
    private frmEntrenador_f parent;
    private int indice,xMouse,yMouse;
    
    
    public frmEjercicio_f(frmEntrenador_f parent) {
        initComponents();
        this.parent = parent;
        this.esParaRemplazar = false;
    }
     public frmEjercicio_f(frmEntrenador_f parent, Ejercicio ejercicio, int indice) {
        initComponents();
        this.parent = parent;
        this.indice = indice;
        this.esParaRemplazar = true;
        
        txtNombreEjercicio.setText(ejercicio.getNombreEjercicio());
        txtSeries.setText(String.valueOf(ejercicio.getSeries()));
        txtReps.setText(String.valueOf(ejercicio.getRepeticiones()));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupoSeries = new javax.swing.ButtonGroup();
        grupoReps = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        pnlHeading = new javax.swing.JPanel();
        pnlExitBtn = new javax.swing.JPanel();
        lblExitBtn = new javax.swing.JLabel();
        rb12reps = new javax.swing.JRadioButton();
        lblSeries = new javax.swing.JLabel();
        rb10reps = new javax.swing.JRadioButton();
        txtReps = new javax.swing.JTextField();
        cbNombreEjercicios = new javax.swing.JComboBox<>();
        rb2serie = new javax.swing.JRadioButton();
        txtSeries = new javax.swing.JTextField();
        lblReps = new javax.swing.JLabel();
        rbOtraReps = new javax.swing.JRadioButton();
        rb4serie = new javax.swing.JRadioButton();
        rbOtraSerie = new javax.swing.JRadioButton();
        rb3serie = new javax.swing.JRadioButton();
        lblNombreEjercicio = new javax.swing.JLabel();
        rb8reps = new javax.swing.JRadioButton();
        rbFalloreps = new javax.swing.JRadioButton();
        txtNombreEjercicio = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        rb1serie = new javax.swing.JRadioButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        pnlCancelar = new javax.swing.JPanel();
        lblCancelar = new javax.swing.JLabel();
        pnlAñadirEjercicio = new javax.swing.JPanel();
        lblAñadirEjercicio = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnlHeading.setBackground(new java.awt.Color(255, 153, 0));
        pnlHeading.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                pnlHeadingMouseDragged(evt);
            }
        });
        pnlHeading.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pnlHeadingMousePressed(evt);
            }
        });

        pnlExitBtn.setBackground(new java.awt.Color(255, 153, 0));

        lblExitBtn.setFont(new java.awt.Font("Open Sans", 1, 24)); // NOI18N
        lblExitBtn.setForeground(new java.awt.Color(255, 255, 255));
        lblExitBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblExitBtn.setText("X");
        lblExitBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblExitBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblExitBtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblExitBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblExitBtnMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblExitBtnMousePressed(evt);
            }
        });

        javax.swing.GroupLayout pnlExitBtnLayout = new javax.swing.GroupLayout(pnlExitBtn);
        pnlExitBtn.setLayout(pnlExitBtnLayout);
        pnlExitBtnLayout.setHorizontalGroup(
            pnlExitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlExitBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        pnlExitBtnLayout.setVerticalGroup(
            pnlExitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlExitBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout pnlHeadingLayout = new javax.swing.GroupLayout(pnlHeading);
        pnlHeading.setLayout(pnlHeadingLayout);
        pnlHeadingLayout.setHorizontalGroup(
            pnlHeadingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeadingLayout.createSequentialGroup()
                .addComponent(pnlExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlHeadingLayout.setVerticalGroup(
            pnlHeadingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHeadingLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(pnlExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 700, 50));

        rb12reps.setBackground(new java.awt.Color(0, 0, 0));
        grupoReps.add(rb12reps);
        rb12reps.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        rb12reps.setForeground(new java.awt.Color(255, 255, 255));
        rb12reps.setText("12 Repeticiones");
        jPanel1.add(rb12reps, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 250, 150, -1));

        lblSeries.setBackground(new java.awt.Color(0, 0, 0));
        lblSeries.setFont(new java.awt.Font("Open Sans", 1, 18)); // NOI18N
        lblSeries.setForeground(new java.awt.Color(255, 255, 255));
        lblSeries.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblSeries.setText("Series");
        jPanel1.add(lblSeries, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 160, 150, -1));

        rb10reps.setBackground(new java.awt.Color(0, 0, 0));
        grupoReps.add(rb10reps);
        rb10reps.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        rb10reps.setForeground(new java.awt.Color(255, 255, 255));
        rb10reps.setSelected(true);
        rb10reps.setText("10 Repeticiones");
        rb10reps.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb10repsActionPerformed(evt);
            }
        });
        jPanel1.add(rb10reps, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 220, 150, -1));

        txtReps.setBackground(new java.awt.Color(0, 0, 0));
        txtReps.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        txtReps.setForeground(new java.awt.Color(153, 153, 153));
        txtReps.setText("...");
        txtReps.setBorder(null);
        txtReps.setEnabled(false);
        txtReps.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtRepsFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtRepsFocusLost(evt);
            }
        });
        txtReps.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtRepsKeyTyped(evt);
            }
        });
        jPanel1.add(txtReps, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 340, 150, -1));

        cbNombreEjercicios.setBackground(new java.awt.Color(0, 0, 0));
        cbNombreEjercicios.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        cbNombreEjercicios.setForeground(new java.awt.Color(255, 255, 255));
        cbNombreEjercicios.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sentadilla", "Flexion", "Dominadas", "Peso Muerto", "Remo", "Dominadas", "Curl" }));
        cbNombreEjercicios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbNombreEjerciciosActionPerformed(evt);
            }
        });
        jPanel1.add(cbNombreEjercicios, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 117, -1));

        rb2serie.setBackground(new java.awt.Color(0, 0, 0));
        grupoSeries.add(rb2serie);
        rb2serie.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        rb2serie.setForeground(new java.awt.Color(255, 255, 255));
        rb2serie.setText("2 Series");
        rb2serie.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rb2serieMouseClicked(evt);
            }
        });
        rb2serie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb2serieActionPerformed(evt);
            }
        });
        jPanel1.add(rb2serie, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 220, 150, -1));

        txtSeries.setBackground(new java.awt.Color(0, 0, 0));
        txtSeries.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        txtSeries.setForeground(new java.awt.Color(153, 153, 153));
        txtSeries.setText("...");
        txtSeries.setBorder(null);
        txtSeries.setEnabled(false);
        txtSeries.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtSeriesFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtSeriesFocusLost(evt);
            }
        });
        txtSeries.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSeriesKeyTyped(evt);
            }
        });
        jPanel1.add(txtSeries, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 340, 150, -1));

        lblReps.setBackground(new java.awt.Color(0, 0, 0));
        lblReps.setFont(new java.awt.Font("Open Sans", 1, 18)); // NOI18N
        lblReps.setForeground(new java.awt.Color(255, 255, 255));
        lblReps.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblReps.setText("Repeticiones");
        jPanel1.add(lblReps, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 160, 150, -1));

        rbOtraReps.setBackground(new java.awt.Color(0, 0, 0));
        grupoReps.add(rbOtraReps);
        rbOtraReps.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        rbOtraReps.setForeground(new java.awt.Color(255, 255, 255));
        rbOtraReps.setText("Otra cantidad");
        rbOtraReps.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rbOtraRepsStateChanged(evt);
            }
        });
        rbOtraReps.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbOtraRepsActionPerformed(evt);
            }
        });
        jPanel1.add(rbOtraReps, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 310, 150, -1));

        rb4serie.setBackground(new java.awt.Color(0, 0, 0));
        grupoSeries.add(rb4serie);
        rb4serie.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        rb4serie.setForeground(new java.awt.Color(255, 255, 255));
        rb4serie.setText("4 Series");
        jPanel1.add(rb4serie, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 280, 150, -1));

        rbOtraSerie.setBackground(new java.awt.Color(0, 0, 0));
        grupoSeries.add(rbOtraSerie);
        rbOtraSerie.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        rbOtraSerie.setForeground(new java.awt.Color(255, 255, 255));
        rbOtraSerie.setText("Otra cantidad");
        rbOtraSerie.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rbOtraSerieStateChanged(evt);
            }
        });
        jPanel1.add(rbOtraSerie, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 310, 150, -1));

        rb3serie.setBackground(new java.awt.Color(0, 0, 0));
        grupoSeries.add(rb3serie);
        rb3serie.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        rb3serie.setForeground(new java.awt.Color(255, 255, 255));
        rb3serie.setText("3 Series");
        jPanel1.add(rb3serie, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 250, 150, -1));

        lblNombreEjercicio.setBackground(new java.awt.Color(0, 0, 0));
        lblNombreEjercicio.setFont(new java.awt.Font("Open Sans", 1, 18)); // NOI18N
        lblNombreEjercicio.setForeground(new java.awt.Color(255, 255, 255));
        lblNombreEjercicio.setText("Nombre Ejercicio");
        jPanel1.add(lblNombreEjercicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        rb8reps.setBackground(new java.awt.Color(0, 0, 0));
        grupoReps.add(rb8reps);
        rb8reps.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        rb8reps.setForeground(new java.awt.Color(255, 255, 255));
        rb8reps.setText("8 Repeticiones");
        jPanel1.add(rb8reps, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 190, 150, -1));

        rbFalloreps.setBackground(new java.awt.Color(0, 0, 0));
        grupoReps.add(rbFalloreps);
        rbFalloreps.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        rbFalloreps.setForeground(new java.awt.Color(255, 255, 255));
        rbFalloreps.setText("All fallo");
        rbFalloreps.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbFallorepsActionPerformed(evt);
            }
        });
        jPanel1.add(rbFalloreps, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 280, 150, 30));

        txtNombreEjercicio.setBackground(new java.awt.Color(0, 0, 0));
        txtNombreEjercicio.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        txtNombreEjercicio.setForeground(new java.awt.Color(153, 153, 153));
        txtNombreEjercicio.setText("Nombre de otro ejercicio...");
        txtNombreEjercicio.setToolTipText("");
        txtNombreEjercicio.setBorder(null);
        txtNombreEjercicio.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtNombreEjercicioFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtNombreEjercicioFocusLost(evt);
            }
        });
        txtNombreEjercicio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreEjercicioKeyTyped(evt);
            }
        });
        jPanel1.add(txtNombreEjercicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 200, 30));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Open Sans", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Ejercicio");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 700, 50));

        rb1serie.setBackground(new java.awt.Color(0, 0, 0));
        grupoSeries.add(rb1serie);
        rb1serie.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        rb1serie.setForeground(new java.awt.Color(255, 255, 255));
        rb1serie.setText("1 Serie");
        jPanel1.add(rb1serie, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 190, 150, -1));

        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 360, 150, 20));

        jSeparator2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 200, 20));

        jSeparator3.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 360, 150, 20));

        pnlCancelar.setBackground(new java.awt.Color(255, 153, 0));

        lblCancelar.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblCancelar.setForeground(new java.awt.Color(255, 255, 255));
        lblCancelar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCancelar.setText("Cancelar");
        lblCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblCancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCancelarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblCancelarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblCancelarMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblCancelarMousePressed(evt);
            }
        });

        javax.swing.GroupLayout pnlCancelarLayout = new javax.swing.GroupLayout(pnlCancelar);
        pnlCancelar.setLayout(pnlCancelarLayout);
        pnlCancelarLayout.setHorizontalGroup(
            pnlCancelarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        pnlCancelarLayout.setVerticalGroup(
            pnlCancelarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        jPanel1.add(pnlCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 420, 140, 50));

        pnlAñadirEjercicio.setBackground(new java.awt.Color(255, 153, 0));

        lblAñadirEjercicio.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblAñadirEjercicio.setForeground(new java.awt.Color(255, 255, 255));
        lblAñadirEjercicio.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAñadirEjercicio.setText("Añadir Ejercicio");
        lblAñadirEjercicio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblAñadirEjercicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAñadirEjercicioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAñadirEjercicioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblAñadirEjercicioMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblAñadirEjercicioMousePressed(evt);
            }
        });

        javax.swing.GroupLayout pnlAñadirEjercicioLayout = new javax.swing.GroupLayout(pnlAñadirEjercicio);
        pnlAñadirEjercicio.setLayout(pnlAñadirEjercicioLayout);
        pnlAñadirEjercicioLayout.setHorizontalGroup(
            pnlAñadirEjercicioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblAñadirEjercicio, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        pnlAñadirEjercicioLayout.setVerticalGroup(
            pnlAñadirEjercicioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblAñadirEjercicio, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        jPanel1.add(pnlAñadirEjercicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 420, 140, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreEjercicioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreEjercicioKeyTyped
        filtrarCaracteres(true, evt);
    }//GEN-LAST:event_txtNombreEjercicioKeyTyped

    private void rbOtraRepsStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rbOtraRepsStateChanged
        if(rbOtraReps.isSelected()) {
            txtReps.setEnabled(true);
            return;
        }
        txtReps.setText("");
        txtReps.setEnabled(false);
    }//GEN-LAST:event_rbOtraRepsStateChanged

    private void rbOtraSerieStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rbOtraSerieStateChanged
        if(rbOtraSerie.isSelected()) {
            txtSeries.setEnabled(true);
            return;
        }
        txtSeries.setText("");
        txtSeries.setEnabled(false);
    }//GEN-LAST:event_rbOtraSerieStateChanged

    private void txtRepsKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtRepsKeyTyped
        filtrarCaracteres(false, evt);
    }//GEN-LAST:event_txtRepsKeyTyped

    private void txtSeriesKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSeriesKeyTyped
        filtrarCaracteres(false, evt);
    }//GEN-LAST:event_txtSeriesKeyTyped

    private void cbNombreEjerciciosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbNombreEjerciciosActionPerformed
        txtNombreEjercicio.setText(String.valueOf(cbNombreEjercicios.getSelectedItem()));
    }//GEN-LAST:event_cbNombreEjerciciosActionPerformed

    private void rb2serieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb2serieActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rb2serieActionPerformed

    private void rb10repsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb10repsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rb10repsActionPerformed

    private void rbOtraRepsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbOtraRepsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbOtraRepsActionPerformed

    private void rbFallorepsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbFallorepsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbFallorepsActionPerformed

    private void txtNombreEjercicioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtNombreEjercicioFocusGained
        if (txtNombreEjercicio.getText().equals("Nombre de otro ejercicio...")) {
            txtNombreEjercicio.setForeground(Color.white);
            txtNombreEjercicio.setText("");
        }
    }//GEN-LAST:event_txtNombreEjercicioFocusGained

    private void txtNombreEjercicioFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtNombreEjercicioFocusLost
          if (txtNombreEjercicio.getText().equals("")) {
            Color grey = new Color(153,153,153);
            txtNombreEjercicio.setForeground(grey);
            txtNombreEjercicio.setText("Nombre de otro ejercicio...");
        }
    }//GEN-LAST:event_txtNombreEjercicioFocusLost

    private void txtSeriesFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtSeriesFocusGained
        if (txtSeries.getText().equals("...")) {
            txtSeries.setForeground(Color.white);
            txtSeries.setText("");
        }
    }//GEN-LAST:event_txtSeriesFocusGained

    private void txtSeriesFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtSeriesFocusLost
        if (txtSeries.getText().equals("")) {
            Color grey = new Color(153,153,153);
            txtSeries.setForeground(grey);
            txtSeries.setText("...");
        }
    }//GEN-LAST:event_txtSeriesFocusLost

    private void txtRepsFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtRepsFocusGained
         if (txtReps.getText().equals("...")) {
            txtReps.setForeground(Color.white);
            txtReps.setText("");
        }
    }//GEN-LAST:event_txtRepsFocusGained

    private void txtRepsFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtRepsFocusLost
         if (txtReps.getText().equals("")) {
            Color grey = new Color(153,153,153);
            txtReps.setForeground(grey);
            txtReps.setText("...");
        }
    }//GEN-LAST:event_txtRepsFocusLost

    private void lblExitBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMouseClicked
        System.exit(0);
    }//GEN-LAST:event_lblExitBtnMouseClicked

    private void lblExitBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMouseEntered
        pnlExitBtn.setBackground(Color.red);
    }//GEN-LAST:event_lblExitBtnMouseEntered

    private void lblExitBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMouseExited
        pnlExitBtn.setBackground(new Color(255,153,0));
    }//GEN-LAST:event_lblExitBtnMouseExited

    private void lblExitBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMousePressed
        pnlExitBtn.setBackground(new Color(145, 0 , 0));
    }//GEN-LAST:event_lblExitBtnMousePressed

    private void lblCancelarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCancelarMouseEntered
        pnlCancelar.setBackground(new Color(255,192,98));
    }//GEN-LAST:event_lblCancelarMouseEntered

    private void lblCancelarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCancelarMouseExited
        pnlCancelar.setBackground(new Color(255,153,0));
    }//GEN-LAST:event_lblCancelarMouseExited

    private void lblCancelarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCancelarMousePressed
        pnlCancelar.setBackground(new Color(255, 120 , 0));
    }//GEN-LAST:event_lblCancelarMousePressed

    private void lblAñadirEjercicioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirEjercicioMouseEntered
        pnlAñadirEjercicio.setBackground(new Color(255,192,98));
    }//GEN-LAST:event_lblAñadirEjercicioMouseEntered

    private void lblAñadirEjercicioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirEjercicioMouseExited
        pnlAñadirEjercicio.setBackground(new Color(255,153,0));
    }//GEN-LAST:event_lblAñadirEjercicioMouseExited

    private void lblAñadirEjercicioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirEjercicioMousePressed
        pnlAñadirEjercicio.setBackground(new Color(255, 120 , 0));
    }//GEN-LAST:event_lblAñadirEjercicioMousePressed

    private void lblCancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCancelarMouseClicked
        parent.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_lblCancelarMouseClicked

    private void lblAñadirEjercicioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAñadirEjercicioMouseClicked
        if(!validarCampos()) {
            return;
        }

        String nombreEjer = txtNombreEjercicio.getText();
        int serie = checkRadioButtons(true); // metodos solo para ordenar el codigo
        int rep = checkRadioButtons(false);

        if(esParaRemplazar == false) {
            parent.añadirEjercicio(new Ejercicio(nombreEjer, serie, rep));
        } else {
            parent.remplazarEjercicio(new Ejercicio(nombreEjer, serie, rep), indice);
        }
        parent.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_lblAñadirEjercicioMouseClicked

    private void pnlHeadingMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlHeadingMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_pnlHeadingMouseDragged

    private void pnlHeadingMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlHeadingMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_pnlHeadingMousePressed

    private void rb2serieMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rb2serieMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rb2serieMouseClicked


    // FUNCIONES
    
    private int checkRadioButtons(boolean esSerie) {
        if(esSerie) {
            
            if(rbOtraSerie.isSelected()) return Integer.parseInt(txtSeries.getText());
            
            if(rb1serie.isSelected()) return 1;
            
            if(rb2serie.isSelected()) return 2;
            
            if(rb3serie.isSelected()) return 3;
            
            if(rb4serie.isSelected()) return 4;
        }
        
        if(rbOtraReps.isSelected()) return Integer.parseInt(txtReps.getText());
        
        if(rb8reps.isSelected()) return 8;
        
        if(rb10reps.isSelected()) return 10;
        
        if(rb12reps.isSelected()) return 12;
        
        if(rbFalloreps.isSelected()) return 0; ; // cero significa al fallo
        
        return 9*9*9*9*9*9*9;  // para que no tire error por "missing return", en validarCampos se comprueba si hay alguno selec
    }
    
    private static void filtrarCaracteres(boolean filtrarNumeros, java.awt.event.KeyEvent evt) {
        char ch = evt.getKeyChar();
        
        if(filtrarNumeros) {
            if( (ch < 'a' || ch > 'z') && (ch < 'A' || ch > 'Z') ) evt.consume();
            return;
        }
        
        if(ch < '0' || ch > '9') evt.consume();
    }
    
    private boolean validarCampos() {
        if(txtNombreEjercicio.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Seleccionade/Complete el nombre de ejercicio");
            return false;
        }
        if(rbOtraSerie.isSelected()) {
            if(txtSeries.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Seleccione/Complete el campo de las series");
                return false;
            }
        }
        if(rbOtraReps.isSelected()) {
            if(txtReps.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Seleccione/Complete el campo de las series");
                return false;
            }
        }
        if(checkRadioButtons(true) == 999 || checkRadioButtons(false) == 999) { // si los dos me devuelven 999 devolver true
            JOptionPane.showMessageDialog(null, "Seleccionar algun radio button de series o repeticiones");
        }
        return true;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbNombreEjercicios;
    private javax.swing.ButtonGroup grupoReps;
    private javax.swing.ButtonGroup grupoSeries;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JLabel lblAñadirEjercicio;
    private javax.swing.JLabel lblCancelar;
    private javax.swing.JLabel lblExitBtn;
    private javax.swing.JLabel lblNombreEjercicio;
    private javax.swing.JLabel lblReps;
    private javax.swing.JLabel lblSeries;
    private javax.swing.JPanel pnlAñadirEjercicio;
    private javax.swing.JPanel pnlCancelar;
    private javax.swing.JPanel pnlExitBtn;
    private javax.swing.JPanel pnlHeading;
    private javax.swing.JRadioButton rb10reps;
    private javax.swing.JRadioButton rb12reps;
    private javax.swing.JRadioButton rb1serie;
    private javax.swing.JRadioButton rb2serie;
    private javax.swing.JRadioButton rb3serie;
    private javax.swing.JRadioButton rb4serie;
    private javax.swing.JRadioButton rb8reps;
    private javax.swing.JRadioButton rbFalloreps;
    private javax.swing.JRadioButton rbOtraReps;
    private javax.swing.JRadioButton rbOtraSerie;
    private javax.swing.JTextField txtNombreEjercicio;
    private javax.swing.JTextField txtReps;
    private javax.swing.JTextField txtSeries;
    // End of variables declaration//GEN-END:variables
}
