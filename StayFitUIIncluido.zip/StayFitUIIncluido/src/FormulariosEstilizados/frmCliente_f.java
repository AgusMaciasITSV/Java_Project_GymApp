package FormulariosEstilizados;

import Clases.Cliente;
import Clases.Dia;
import Clases.Ejercicio;
import com.sun.source.tree.ParenthesizedTree;
import java.awt.Color;
import javax.swing.DefaultListModel;

public class frmCliente_f extends javax.swing.JFrame {

    private int xMouse,yMouse;
    Color lOrange = new Color(255,192,98);
    Color orange = new Color(255,153,0);
    Color dOrange = new Color(255,120 ,0);
    Color white = new Color(255,255,255);
    Color grey = new Color(153,153,153);
    Color red = new Color(255,0,0);
    Color dRed = new Color(145,0 ,0);
    
    private Cliente cliente;
    private DefaultListModel dmList = new DefaultListModel();
    private frmLogIn_f parent;
    
    public frmCliente_f(Cliente client, frmLogIn_f parent) {
        initComponents();
        this.setLocationRelativeTo(null);
        this.parent = parent;
        
        
        
        lstListaEjercicios.setModel(dmList);
        
        this.cliente = client;
        
        System.out.println(cliente);
        
        String nombre = cliente.getInformacion().getNombre();
        lblNombre.setText(lblNombre.getText() + nombre);
        
        String apellido = cliente.getInformacion().getApellido();
        lblApellido.setText(lblApellido.getText() + apellido);
        
        int edad = cliente.getInformacion().getEdad();
        lblEdad.setText(lblEdad.getText() + edad);
        
        actualizarCbPlanes();
        //actualizarCbDias();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblPlanesDelCliente = new javax.swing.JLabel();
        pnlHeading = new javax.swing.JPanel();
        pnlExitBtn = new javax.swing.JPanel();
        lblExitBtn = new javax.swing.JLabel();
        scrlPnlListaEjercicios = new javax.swing.JScrollPane();
        lstListaEjercicios = new javax.swing.JList<>();
        lblNombreHeading = new javax.swing.JLabel();
        lblApellidoHeading = new javax.swing.JLabel();
        lblEdadHeading = new javax.swing.JLabel();
        lblPlanes = new javax.swing.JLabel();
        lblDia = new javax.swing.JLabel();
        lblEjercicios = new javax.swing.JLabel();
        cbxPlanes = new javax.swing.JComboBox<>();
        cbxDia = new javax.swing.JComboBox<>();
        lblNombre = new javax.swing.JLabel();
        lblEdad = new javax.swing.JLabel();
        lblApellido = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblPlanesDelCliente.setBackground(new java.awt.Color(0, 0, 0));
        lblPlanesDelCliente.setFont(new java.awt.Font("Open Sans", 1, 36)); // NOI18N
        lblPlanesDelCliente.setForeground(new java.awt.Color(255, 255, 255));
        lblPlanesDelCliente.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPlanesDelCliente.setText("Planes del Cliente");
        jPanel1.add(lblPlanesDelCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 500, -1));

        pnlHeading.setBackground(new java.awt.Color(255, 153, 0));
        pnlHeading.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                pnlHeadingMouseDragged(evt);
            }
        });
        pnlHeading.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pnlHeadingMousePressed(evt);
            }
        });

        pnlExitBtn.setBackground(new java.awt.Color(255, 153, 0));

        lblExitBtn.setFont(new java.awt.Font("Open Sans", 1, 24)); // NOI18N
        lblExitBtn.setForeground(new java.awt.Color(255, 255, 255));
        lblExitBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblExitBtn.setText("X");
        lblExitBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblExitBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblExitBtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblExitBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblExitBtnMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblExitBtnMousePressed(evt);
            }
        });

        javax.swing.GroupLayout pnlExitBtnLayout = new javax.swing.GroupLayout(pnlExitBtn);
        pnlExitBtn.setLayout(pnlExitBtnLayout);
        pnlExitBtnLayout.setHorizontalGroup(
            pnlExitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblExitBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );
        pnlExitBtnLayout.setVerticalGroup(
            pnlExitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlExitBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout pnlHeadingLayout = new javax.swing.GroupLayout(pnlHeading);
        pnlHeading.setLayout(pnlHeadingLayout);
        pnlHeadingLayout.setHorizontalGroup(
            pnlHeadingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeadingLayout.createSequentialGroup()
                .addComponent(pnlExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlHeadingLayout.setVerticalGroup(
            pnlHeadingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHeadingLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(pnlExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(pnlHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 50));

        scrlPnlListaEjercicios.setBackground(new java.awt.Color(0, 0, 0));

        lstListaEjercicios.setBackground(new java.awt.Color(0, 0, 0));
        lstListaEjercicios.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        lstListaEjercicios.setForeground(new java.awt.Color(255, 255, 255));
        scrlPnlListaEjercicios.setViewportView(lstListaEjercicios);

        jPanel1.add(scrlPnlListaEjercicios, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 170, 200, 250));

        lblNombreHeading.setBackground(new java.awt.Color(0, 0, 0));
        lblNombreHeading.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblNombreHeading.setForeground(new java.awt.Color(255, 255, 255));
        lblNombreHeading.setText("Nombre:");
        jPanel1.add(lblNombreHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 70, 30));

        lblApellidoHeading.setBackground(new java.awt.Color(0, 0, 0));
        lblApellidoHeading.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblApellidoHeading.setForeground(new java.awt.Color(255, 255, 255));
        lblApellidoHeading.setText("Apellido:");
        jPanel1.add(lblApellidoHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 70, 30));

        lblEdadHeading.setBackground(new java.awt.Color(0, 0, 0));
        lblEdadHeading.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblEdadHeading.setForeground(new java.awt.Color(255, 255, 255));
        lblEdadHeading.setText("Edad:");
        jPanel1.add(lblEdadHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 70, 30));

        lblPlanes.setBackground(new java.awt.Color(0, 0, 0));
        lblPlanes.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblPlanes.setForeground(new java.awt.Color(255, 255, 255));
        lblPlanes.setText("Planes");
        jPanel1.add(lblPlanes, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 60, 30));

        lblDia.setBackground(new java.awt.Color(0, 0, 0));
        lblDia.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        lblDia.setForeground(new java.awt.Color(255, 255, 255));
        lblDia.setText("Dia");
        jPanel1.add(lblDia, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 60, 30));

        lblEjercicios.setBackground(new java.awt.Color(0, 0, 0));
        lblEjercicios.setFont(new java.awt.Font("Open Sans", 1, 18)); // NOI18N
        lblEjercicios.setForeground(new java.awt.Color(255, 255, 255));
        lblEjercicios.setText("Ejercicios");
        jPanel1.add(lblEjercicios, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 130, 90, -1));

        cbxPlanes.setBackground(new java.awt.Color(0, 0, 0));
        cbxPlanes.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        cbxPlanes.setForeground(new java.awt.Color(255, 255, 255));
        cbxPlanes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxPlanesActionPerformed(evt);
            }
        });
        jPanel1.add(cbxPlanes, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 320, 120, -1));

        cbxDia.setBackground(new java.awt.Color(0, 0, 0));
        cbxDia.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        cbxDia.setForeground(new java.awt.Color(255, 255, 255));
        cbxDia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxDiaActionPerformed(evt);
            }
        });
        jPanel1.add(cbxDia, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 360, 120, -1));

        lblNombre.setBackground(new java.awt.Color(0, 0, 0));
        lblNombre.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        lblNombre.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(lblNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, 120, 30));

        lblEdad.setBackground(new java.awt.Color(0, 0, 0));
        lblEdad.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        lblEdad.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(lblEdad, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, 120, 30));

        lblApellido.setBackground(new java.awt.Color(0, 0, 0));
        lblApellido.setFont(new java.awt.Font("Open Sans", 0, 14)); // NOI18N
        lblApellido.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(lblApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 210, 120, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblExitBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMouseClicked
        parent.guardar();
        System.exit(0);
    }//GEN-LAST:event_lblExitBtnMouseClicked

    private void lblExitBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMouseEntered
        pnlExitBtn.setBackground(red);
    }//GEN-LAST:event_lblExitBtnMouseEntered

    private void lblExitBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMouseExited
        pnlExitBtn.setBackground(orange);
    }//GEN-LAST:event_lblExitBtnMouseExited

    private void lblExitBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitBtnMousePressed
        pnlExitBtn.setBackground(dRed);
    }//GEN-LAST:event_lblExitBtnMousePressed

    private void pnlHeadingMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlHeadingMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_pnlHeadingMouseDragged

    private void pnlHeadingMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlHeadingMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_pnlHeadingMousePressed

    private void cbxPlanesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxPlanesActionPerformed
        actualizarCbDias();
        
    }//GEN-LAST:event_cbxPlanesActionPerformed

    private void cbxDiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxDiaActionPerformed
       // System.out.println("ejecutando ando");
        if(cbxDia.getSelectedIndex() != -1){
            dmList.clear();
            Dia dia = cliente.getListaPlanes().get(cbxPlanes.getSelectedIndex()).getListaDias().get(cbxDia.getSelectedIndex());

            if(dia.getListaEjercicios().isEmpty()) {
                return;
            }

            for (Ejercicio ejer : dia.getListaEjercicios()) {

                String nombreEjer = ejer.getNombreEjercicio();
                int series = ejer.getSeries();
                int reps = ejer.getRepeticiones();

                if(reps == 0) {
                    dmList.addElement(nombreEjer + ": " + series + " x al fallo");
                } else {
                    dmList.addElement(nombreEjer + ": " + series + " x " + reps);
                }
            }
        }
    }//GEN-LAST:event_cbxDiaActionPerformed

    
    private void actualizarCbPlanes() {
        
        cbxPlanes.removeAllItems();
        
        
        
        if(cliente.getListaPlanes().isEmpty()) {
            return;
        }
        
        for (int i = 0; i < cliente.getListaPlanes().size(); i++) {
            cbxPlanes.addItem("Plan N°" + (i+1));
        }
        
        actualizarCbDias();
    }
    
    private void actualizarCbDias() {
            cbxDia.removeAllItems();
        
        
        if(cliente.getListaPlanes().isEmpty()) {
            return;
        }
        
        int cantDias = 
                cliente.getListaPlanes().
                get(cbxPlanes.getSelectedIndex()).
                getListaDias().size();
        
        for (int i = 0; i < cantDias; i++) {
            cbxDia.addItem("Dia N°" + (i+1));
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbxDia;
    private javax.swing.JComboBox<String> cbxPlanes;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblApellido;
    private javax.swing.JLabel lblApellidoHeading;
    private javax.swing.JLabel lblDia;
    private javax.swing.JLabel lblEdad;
    private javax.swing.JLabel lblEdadHeading;
    private javax.swing.JLabel lblEjercicios;
    private javax.swing.JLabel lblExitBtn;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblNombreHeading;
    private javax.swing.JLabel lblPlanes;
    private javax.swing.JLabel lblPlanesDelCliente;
    private javax.swing.JList<String> lstListaEjercicios;
    private javax.swing.JPanel pnlExitBtn;
    private javax.swing.JPanel pnlHeading;
    private javax.swing.JScrollPane scrlPnlListaEjercicios;
    // End of variables declaration//GEN-END:variables
}
