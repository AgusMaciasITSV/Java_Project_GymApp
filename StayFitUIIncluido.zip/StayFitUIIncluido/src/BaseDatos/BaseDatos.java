package BaseDatos;

import Clases.Cliente;
import Clases.Dia;
import Clases.Ejercicio;
import Clases.Entrenador;
import Clases.Informacion;
import Clases.Plan;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class BaseDatos {
    
    public static void escribirEntrenadores(ArrayList<Entrenador> lista) {
        PrintWriter salida = null;
        try {
            salida = new PrintWriter(new BufferedWriter(new FileWriter("Entrenadores.txt")));
            
            for (int i = 0; i < lista.size(); i++) {
                
                String usuario = lista.get(i).getUsuario();
                String nombre = lista.get(i).getInformacion().getNombre();
                String apellido = lista.get(i).getInformacion().getApellido();
                int edad = lista.get(i).getInformacion().getEdad();
                String contra = lista.get(i).getContraseña();
                
                salida.println(usuario + "&" + nombre + "&" + apellido + "&" + edad + "&" + contra);     
            }
            
        } catch (IOException ex) {
            String mensaje = "Error al intentar cargar los datos: no se ha encontrado ningun archivo para cargar. Se creara uno automaticamente";
            int tipoJOption = JOptionPane.INFORMATION_MESSAGE;
            JOptionPane.showMessageDialog(null, mensaje, "ERROR", tipoJOption);
        } finally {
            salida.close();
        }
    }
    
    public static ArrayList<Entrenador> leerEntrenadores(){
        ArrayList<Entrenador> listaEntrenador = new ArrayList<>();
        try (BufferedReader entrada = new BufferedReader(new FileReader("Entrenadores.txt"))){
            String s, s2 = new String();
            
            String usuario, nombre, contra, apellido;
            int edad;
            
            
            
            while ((s = entrada.readLine()) != null) {
                s2 += s + "\n";
                String[] listaTxt = s.split("&");
                
                usuario = listaTxt[0];
                nombre = listaTxt[1];
                apellido = listaTxt[2];
                edad = Integer.parseInt(listaTxt[3]);
                contra = listaTxt[4];
                
                Informacion info = new Informacion(nombre, apellido, edad);
                Entrenador entrenador = new Entrenador(usuario, info, contra);
                listaEntrenador.add(entrenador);
            }
            
            entrada.close();
            
        } catch (IOException e) {
            String mensaje = "Error al intentar leer los datos: no se ha encontrado ningun archivo para leer. Se creara uno automaticamente";
            int tipoJOption = JOptionPane.INFORMATION_MESSAGE;
            JOptionPane.showMessageDialog(null, mensaje, "ERROR", tipoJOption);
        }
        return listaEntrenador;
    }
    
    public static void escribirClientes(ArrayList<Cliente> listaCliente) {
        try (PrintWriter salidaCl = new PrintWriter(new BufferedWriter(new FileWriter("Clientes.txt")))) {
            
            for (int i = 0; i < listaCliente.size(); i++) {
                
                Cliente client = listaCliente.get(i);
                
                String usuario = client.getUsuario();
                String nombre = client.getInformacion().getNombre();
                String apellido = client.getInformacion().getApellido();
                int edad = client.getInformacion().getEdad();
                String contra = client.getContraseña();
                String planes = "";
                
                
                if(!client.getListaPlanes().isEmpty()) {
                    for (int j = 0; j < client.getListaPlanes().size(); j++) {
                        Plan plan = client.getListaPlanes().get(i);
                       
                        for (int k = 0; k < plan.getListaDias().size(); k++) {
                            Dia dia = plan.getListaDias().get(k);
                            
                            for (int l = 0; l < dia.getListaEjercicios().size(); l++) {
                                Ejercicio ejer = dia.getListaEjercicios().get(l);
                                
                                String nombreEjer = ejer.getNombreEjercicio();
                                int series = ejer.getSeries();
                                int rep = ejer.getRepeticiones();
                                
                                planes += nombreEjer + "=" + series + "=" + rep;
                                
                                if(dia.getListaEjercicios().size() > 1) {
                                    if(l != dia.getListaEjercicios().size() - 1) {
                                        planes += ";";
                                    }
                                }
                            }
                            
                            if(plan.getListaDias().size() > 1) {
                                if(k != plan.getListaDias().size() -1) {
                                    planes += "/";
                                }
                            }
                        }
                        
                        if( client.getListaPlanes().size() > 1) {
                            if(j != client.getListaPlanes().size() -1) {
                                planes += "|";
                            }
                        }
                    }
               }  else {
                    planes = "sin_plan";
                }
                
                salidaCl.println(usuario + "&" + nombre + "&" + apellido + "&" + edad + "&" + contra + "&" + planes);
        
            }
            salidaCl.close();
            
            
        } catch (IOException ex) {
            String mensaje = "Error al intentar cargar los datos: no se ha encontrado ningun archivo para cargar. Se creara uno automaticamente";
            int tipoJOption = JOptionPane.INFORMATION_MESSAGE;
            JOptionPane.showMessageDialog(null, mensaje, "ERROR", tipoJOption);
        }
        
    }
    
    public static ArrayList<Cliente> leerClientes() {
        ArrayList<Cliente> listaCliente = new ArrayList();
        
        try (BufferedReader entrada = new BufferedReader(new FileReader("Clientes.txt"))){
            String s, s2 = new String();
            
            String usuario, nombre, contra, apellido;
            int edad;
            
            while ((s = entrada.readLine()) != null) {
                
                s2 += s + "\n";
                String[] listaTxt = s.split("&");

                
                usuario = listaTxt[0];
                nombre = listaTxt[1];
                apellido = listaTxt[2];
                edad = Integer.parseInt(listaTxt[3]);
                contra = listaTxt[4];
                
                ArrayList<Plan> listaPlanes = new ArrayList<>();

                if(!listaTxt[5].equals("sin_plan")) {
                    
                    String[] planesTxt = obtenerLista(listaTxt[5], "|");
                    
                    for (int i = 0; i < planesTxt.length; i++) {
                        String[] dias = obtenerLista(planesTxt[i], "/");
                        ArrayList<Dia> listaDias = new ArrayList();
                    
                        for (int j = 0; j < dias.length; j++) {
                            String[] ejercicios = obtenerLista(dias[j], ";");
                            ArrayList<Ejercicio> listaEjercicios = new ArrayList();
                        
                            for (int k = 0; k < ejercicios.length; k++) {
                                String[] caracTxt = obtenerLista(ejercicios[k], "=");                           
                                
                                String nombreEjer = caracTxt[0];
                                int seriesEjer = Integer.parseInt(caracTxt[1]);
                                int RepEjer = Integer.parseInt(caracTxt[2]);
                            
                                Ejercicio ejer = new Ejercicio(nombreEjer, RepEjer, seriesEjer);
                                listaEjercicios.add(ejer);
                            }
                            
                            Dia dia = new Dia(listaEjercicios);
                            listaDias.add(dia);
                        }
                        
                        Plan plan = new Plan(listaDias);
                        listaPlanes.add(plan);
                    }
                }
                
                    
                Informacion info = new Informacion(nombre, apellido, edad);
                Cliente client = new Cliente(usuario, info, contra, listaPlanes);
                listaCliente.add(client);
                
            }
            
            entrada.close();
            
        } catch (IOException e) {
            String mensaje = "Error al intentar leer los datos: no se ha encontrado ningun archivo para leer. Se creara uno automaticamente";
            int tipoJOption = JOptionPane.INFORMATION_MESSAGE;
            JOptionPane.showMessageDialog(null, mensaje, "ERROR", tipoJOption);
        }
        return listaCliente;
    }

    private static String[] obtenerLista(String listaTxt, String sep) {
        String[] lista = new String[1];
        if(listaTxt.contains(sep)) {
            lista = listaTxt.split(sep);
            return lista;
        }
        
        lista[0] = listaTxt;
        return lista;
    }
}
