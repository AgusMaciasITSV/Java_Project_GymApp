package Clases;

public class Entrenador extends Usuario{
    public Entrenador(String usuario, Informacion informacion, String contraseña) {
        super(usuario, informacion, contraseña);
    }
}
